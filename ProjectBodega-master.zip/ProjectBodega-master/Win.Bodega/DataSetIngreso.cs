﻿namespace Win.Bodega
{


    public partial class DataSetIngreso
    {
    }
}
