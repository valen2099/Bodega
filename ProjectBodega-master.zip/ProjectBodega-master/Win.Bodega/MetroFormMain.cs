﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win.Bodega
{
    public partial class MetroFormMain : MetroFramework.Forms.MetroForm
    {
        public MetroFormMain()
        {
            InitializeComponent();
        }

        private void Login()
        {
            var formLogin = new FormLogin();
            formLogin.ShowDialog();
        }

        private void MetroFormMain_Load(object sender, EventArgs e)
        {
            Login();
        }

        private void AddFormInPanel(Form fh)
        {
            if (this.PanelContedor.Controls.Count > 0)
                this.PanelContedor.Controls.RemoveAt(0);
            fh.TopLevel = false;
            fh.FormBorderStyle = FormBorderStyle.None;
            fh.Dock = DockStyle.Fill;
            this.PanelContedor.Controls.Add(fh);
            this.PanelContedor.Tag = fh;
            fh.Show();
        }
        /*private void AbrirFormHija(Form formhija)
        {
            if (this.PanelContedor.Controls.Count > 0)
            {
                this.PanelContedor.Controls.RemoveAt(0);
            }
            Form formacoplada = formhija as Form;
            formacoplada.TopLevel = false;
            formacoplada.Dock = DockStyle.Fill;
            this.PanelContedor.Controls.Add(formacoplada);
            this.PanelContedor.Tag = formacoplada;
            formacoplada.Show();
        }*/

        private void metroTile1_Click(object sender, EventArgs e)
        {
            //AbrirFormHija(new FormProductos());
            var form = Application.OpenForms.OfType<FormProductos>().FirstOrDefault();
            FormProductos hijo = form ?? new FormProductos();
            AddFormInPanel(hijo);
        }
    }
}
